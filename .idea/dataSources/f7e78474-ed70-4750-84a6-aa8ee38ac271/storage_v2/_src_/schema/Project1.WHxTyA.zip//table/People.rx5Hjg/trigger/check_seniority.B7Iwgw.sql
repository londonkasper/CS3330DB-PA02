create definer = root@localhost trigger check_seniority
    before insert
    on People
    for each row
BEGIN
        SET new.seniority = LOWER(new.seniority);
        IF new.seniority NOT IN ('newbie', 'junior', 'senior')
            THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Seniority must be newbie, junior, or senior';
        END IF;
    END;

